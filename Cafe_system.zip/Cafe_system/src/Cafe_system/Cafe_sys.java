package Cafe_system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.util.regex.*;

public class Cafe_sys extends First_Cafe_Sys {
    private JTextField TxtItm1;
    private JTextField TxtItm2;
    private JTextField TxtItm3;
    private JTextField TxtItm4;
    private JTextField TxtItm5;
    private JTextField TxtItm6;
    private JTextField TxtItm7;
    private JTextField TxtD1;
    private JTextField TxtD2;
    private JTextField TxtD3;
    private JTextField TxtD4;
    private JTextField txt_qutDrink;
    private JTextField txtDisplay;
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField regUsernameField;
    private JPasswordField regPasswordField;
    private UserAuthentication userAuth;
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JLabel lblStatus;
    private JLabel lblRegStatus;

    // =================== Calcy initialization===================
    double firstnum;
    double secondnum;
    double result;
    String operations;
    String answer;
    private double itm1 = 40, itm2 = 199, itm3 = 80, itm4 = 60, itm5 = 50, itm6 = 90, itm7 = 40;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Cafe_sys window = new Cafe_sys();
                    window.frame.setVisible(true);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Cafe_sys() {
        userAuth = new UserAuthentication();
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 600, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createLoginPanel(), "Login");
        mainPanel.add(createRegistrationPanel(), "Register");

        frame.getContentPane().add(mainPanel, BorderLayout.CENTER);

        // Show login panel initially
        cardLayout.show(mainPanel, "Login");
    }

    private JPanel createLoginPanel() {
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(null);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(65, 70, 80, 14);
        loginPanel.add(lblUsername);

        usernameField = new JTextField();
        usernameField.setBounds(155, 67, 150, 20);
        loginPanel.add(usernameField);
        usernameField.setColumns(10);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(65, 120, 80, 14);
        loginPanel.add(lblPassword);

        passwordField = new JPasswordField();
        passwordField.setBounds(155, 117, 150, 20);
        loginPanel.add(passwordField);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(155, 160, 89, 23);
        loginPanel.add(btnLogin);

        lblStatus = new JLabel("");
        lblStatus.setBounds(155, 200, 200, 14);
        loginPanel.add(lblStatus);

        JButton btnGoToRegister = new JButton("Register");
        btnGoToRegister.setBounds(255, 160, 89, 23);
        loginPanel.add(btnGoToRegister);

        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (username.isEmpty() || password.isEmpty()) {
                    lblStatus.setText("Please fill all fields.");
                } else if (userAuth.authenticate(username, password)) {
                    lblStatus.setText("Login successful!");
                } else {
                    lblStatus.setText("Invalid username or password.");
                }

                First_Cafe_Sys sys = new First_Cafe_Sys();
                First_Cafe_Sys.main(null);
            }
        });

        btnGoToRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Register");
            }
        });

        return loginPanel;
    }

    private JPanel createRegistrationPanel() {
        JPanel registerPanel = new JPanel();
        registerPanel.setLayout(null);

        JLabel lblRegUsername = new JLabel("Register Username:");
        lblRegUsername.setBounds(65, 70, 130, 14);
        registerPanel.add(lblRegUsername);

        regUsernameField = new JTextField();
        regUsernameField.setBounds(200, 67, 150, 20);
        registerPanel.add(regUsernameField);
        regUsernameField.setColumns(10);

        JLabel lblRegPassword = new JLabel("Register Password:");
        lblRegPassword.setBounds(65, 120, 130, 14);
        registerPanel.add(lblRegPassword);

        regPasswordField = new JPasswordField();
        regPasswordField.setBounds(200, 117, 150, 20);
        registerPanel.add(regPasswordField);

        JButton btnRegister = new JButton("Register");
        btnRegister.setBounds(155, 160, 100, 23);
        registerPanel.add(btnRegister);

        lblRegStatus = new JLabel("");
        lblRegStatus.setBounds(155, 200, 200, 14);
        registerPanel.add(lblRegStatus);

        JButton btnGoToLogin = new JButton("Login");
        btnGoToLogin.setBounds(265, 160, 89, 23);
        registerPanel.add(btnGoToLogin);

        btnRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String regUsername = regUsernameField.getText();
                String regPassword = new String(regPasswordField.getPassword());

                if (regUsername.isEmpty() || regPassword.isEmpty()) {
                    lblRegStatus.setText("Please fill all fields.");
                } else if (regUsername.length() < 5) {
                    lblRegStatus.setText("Username must be at least 5 characters.");
                } else if (!isValidPassword(regPassword)) {
                    lblRegStatus.setText("Password must be at least 8 characters, and include one uppercase letter, one lowercase letter, one digit, and one special character.");
                } else if (userAuth.register(regUsername, regPassword)) {
                    lblRegStatus.setText("Registration successful!");
                } else {
                    lblRegStatus.setText("Username already exists.");
                }
            }
        });

        btnGoToLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Login");
            }
        });

        return registerPanel;
    }

    private boolean isValidPassword(String password) {
        // Password must contain at least one digit, one uppercase letter, one lowercase letter, and one special character
        String pattern = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[@#$%^&+=]).{8,}$";
        return Pattern.matches(pattern, password);
    }

    class UserAuthentication {
        private Map<String, String> userDatabase;

        public UserAuthentication() {
            userDatabase = new HashMap<>();
            userDatabase.put("user1", "Password1@");
            userDatabase.put("user2", "Password2@");
        }

        public boolean authenticate(String username, String password) {
            if (userDatabase.containsKey(username)) {
                return userDatabase.get(username).equals(password);
            }
            return false;
        }

        public boolean register(String username, String password) {
            if (userDatabase.containsKey(username)) {
                return false; // Username already exists
            }
            userDatabase.put(username, password);
            return true;
        }
    }
}
